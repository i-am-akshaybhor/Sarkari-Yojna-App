package com.example.sarkariyojna.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CategoryModel  implements Serializable {
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("id")
    @Expose
    private String pkId;
    @SerializedName("category_name")
    @Expose
    private String category_name;
    @SerializedName("image")
    @Expose
    private String image;

    public CategoryModel(){

    }

    public CategoryModel(String message, String pkId, String category_name, String image) {
        this.message = message;
        this.pkId = pkId;
        this.category_name = category_name;
        this.image = image;
    }



    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}

