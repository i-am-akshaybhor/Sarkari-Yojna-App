package com.example.sarkariyojna.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CategoryList {
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("Category List")
    @Expose
    private List<CategoryModel> categorylist = null;


    public CategoryList(){

    }

    public CategoryList(String message, List<CategoryModel> categorylist) {
        this.message = message;
        this.categorylist = categorylist;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<CategoryModel> getCategorylist() {
        return categorylist;
    }

    public void setEmployeelist(List<CategoryModel> categorylist) {
        this.categorylist = categorylist;
    }
}
