package com.example.sarkariyojna.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sarkariyojna.Model.MhschemeModel;
import com.example.sarkariyojna.R;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;

public class MhschemeAdapter extends RecyclerView.Adapter<MhschemeAdapter.ViewHolder> {

    private Context mco;
    List<MhschemeModel> mhschemeModels =new ArrayList<MhschemeModel>();


    public MhschemeAdapter(Context mco, List<MhschemeModel> mhschemeModels) {
        this.mco = mco;
        this.mhschemeModels = mhschemeModels;
    }

    @NonNull
    @Override
    public MhschemeAdapter.ViewHolder onCreateViewHolder(ViewGroup ViewGroup, int i) {
        View view= LayoutInflater.from(ViewGroup.getContext()).inflate(R.layout.category_name_list,ViewGroup,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MhschemeAdapter.ViewHolder holder, final int i) {
        final MhschemeModel mhschemeModel =mhschemeModels.get(i);
        holder.scname.setText(mhschemeModel.getName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getRootView().getContext());
                alertbox.setMessage(mhschemeModel.getDescription());
                alertbox.setTitle(mhschemeModel.getName());

                alertbox.setNeutralButton("OK",
                        new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface arg0,
                                                int arg1) {

                            }
                        }).setPositiveButton("View Details", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String url = mhschemeModel.getPdf();
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        mco.startActivity(i);
                    }
                });
                alertbox.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return mhschemeModels.size() ;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView scname;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            scname=itemView.findViewById(R.id.scname);
        }
    }
}
