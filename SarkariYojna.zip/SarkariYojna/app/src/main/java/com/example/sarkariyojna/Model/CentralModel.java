package com.example.sarkariyojna.Model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CentralModel implements Serializable {

    @SerializedName("id")
    @Expose
    private String pkId;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("description")
    @Expose
    private String description;

    @SerializedName("url")
    @Expose
    private String url;


    @SerializedName("pdf")
    @Expose
    private String pdf;

    public CentralModel(String pkId, String name, String description, String url, String pdf) {
        this.pkId = pkId;
        this.name = name;
        this.description = description;
        this.url = url;
        this.pdf = pdf;
    }

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public CentralModel(){



    }
}

