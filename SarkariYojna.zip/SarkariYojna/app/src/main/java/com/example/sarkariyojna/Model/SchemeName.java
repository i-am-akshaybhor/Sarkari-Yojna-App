package com.example.sarkariyojna.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SchemeName {
    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("Scheme_Name")
    @Expose
    private List<MhschemeModel> schemename = null;

    public SchemeName() {

    }

    public SchemeName(String message, List<MhschemeModel> schemename) {
        this.message = message;
        this.schemename = schemename;

    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<MhschemeModel> getSchemename() {
        return schemename;
    }

    public void setSchemename(List<MhschemeModel> schemename) {
        this.schemename = schemename;
    }
}