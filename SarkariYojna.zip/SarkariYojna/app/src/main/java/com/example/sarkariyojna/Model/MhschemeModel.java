package com.example.sarkariyojna.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class MhschemeModel implements Serializable {

    @SerializedName("id")
    @Expose
    private String pkId;
    @SerializedName("category")
    @Expose
    private String category;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("description")
    @Expose
    private String description;

    @SerializedName("url")
    @Expose
    private String url;

    @SerializedName("pdf")
    @Expose
    private String pdf;

    public MhschemeModel(){

    }

    public MhschemeModel(String pkId, String category, String name, String description, String url, String pdf) {
        this.pkId = pkId;
        this.category = category;
        this.name = name;
        this.description = description;
        this.url = url;
        this.pdf = pdf;
    }




    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }
}
