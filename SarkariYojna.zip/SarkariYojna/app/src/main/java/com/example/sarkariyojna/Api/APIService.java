package com.example.sarkariyojna.Api;


import android.provider.SyncStateContract;

import com.example.sarkariyojna.Model.CategoryList;
import com.example.sarkariyojna.Model.CentralList;
import com.example.sarkariyojna.Model.MhschemeModel;
import com.example.sarkariyojna.Model.SchemeName;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;


public interface APIService {



    @GET("getAllCategories.php")
    Call<CategoryList> getallcategories();



    @FormUrlEncoded
    @POST("getscheme_name.php")
    Call<SchemeName> getscheme(
            @Field("category") String category
    );

    @FormUrlEncoded
    @POST("getCentral_name.php")
    Call<CentralList> getcentralname(
            @Field("category") String category
    );




//    @GET("getscheme_name.php")
//    Call<SchemeName> getscheme();

    /*@GET(Constants.GET_NOTICE_LIST)
    Call<List<NoticeModel>> getAllNotice();*/

}
