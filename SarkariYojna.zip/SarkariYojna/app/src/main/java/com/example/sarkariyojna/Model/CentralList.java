package com.example.sarkariyojna.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CentralList {
    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("Central_Name")
    @Expose
    private List<CentralModel> centrallist = null;

    public CentralList() {


    }

    public CentralList(String message, List<CentralModel> centrallist) {
        this.message = message;
        this.centrallist = centrallist;

    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    public List<CentralModel> getCentrallist() {
        return centrallist;
    }




    public void setSchemename(List<MhschemeModel> schemename) {
        this.centrallist = centrallist;
    }


}
