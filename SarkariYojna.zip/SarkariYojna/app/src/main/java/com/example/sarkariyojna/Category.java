package com.example.sarkariyojna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class Category extends AppCompatActivity {
LinearLayout cg,mg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        cg=findViewById(R.id.cg);
        mg=findViewById(R.id.mg);

        cg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Category.this,CentralCategoryActivity.class);
                startActivity(intent);
            }
        });
        mg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Category.this,CategoryListActivity.class);
                startActivity(intent);
            }
        });
    }
}