package com.example.sarkariyojna.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sarkariyojna.DashboardCentral;
import com.example.sarkariyojna.DashboardMaharashtra;
import com.example.sarkariyojna.Model.CategoryModel;
import com.example.sarkariyojna.R;

import java.util.ArrayList;
import java.util.List;

public class CentraCategoryAdapter extends RecyclerView.Adapter<CentraCategoryAdapter.ViewHolder> {

    private Context mContext;
    List<CategoryModel> categoryModels = new ArrayList<CategoryModel>();

    public CentraCategoryAdapter(Context mContext, List<CategoryModel> categoryModels) {
        this.mContext = mContext;
        this.categoryModels = categoryModels;
    }

    @NonNull
    @Override
    public CentraCategoryAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.category_list_item, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CentraCategoryAdapter.ViewHolder holder, int i) {
        final CategoryModel categoryModel=categoryModels.get(i);
        holder.txtsname.setText(categoryModel.getCategory_name());

        Glide.with(mContext)
                .load(categoryModel.getImage())
                .into(holder.image);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(mContext, DashboardCentral.class);
                intent.putExtra("category",categoryModel.getPkId());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return categoryModels.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtsname;
        ImageView image;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtsname=itemView.findViewById(R.id.txtsname);
            image=itemView.findViewById(R.id.image);
        }
    }
}
