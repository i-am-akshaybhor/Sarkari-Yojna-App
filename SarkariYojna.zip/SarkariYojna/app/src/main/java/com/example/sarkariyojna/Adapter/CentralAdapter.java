package com.example.sarkariyojna.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sarkariyojna.Model.CentralModel;
import com.example.sarkariyojna.Model.MhschemeModel;
import com.example.sarkariyojna.R;

import java.util.ArrayList;
import java.util.List;

public class CentralAdapter extends RecyclerView.Adapter<CentralAdapter.ViewHolder> {

    public Context context;
    List<CentralModel> centralModels =new ArrayList<CentralModel>();

    public CentralAdapter(Context context, List<CentralModel> centralModels) {
        this.context = context;
        this.centralModels = centralModels;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup ViewGroup ,int i) {
        View view= LayoutInflater.from(ViewGroup.getContext()).inflate(R.layout.central_schemename_list,ViewGroup,false);
return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int i) {
        final CentralModel centralModel=centralModels.get(i);
        holder.centralname.setText(centralModel.getName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getRootView().getContext());
                alertbox.setMessage(centralModel.getDescription());
                alertbox.setTitle(centralModel.getName());

                alertbox.setNeutralButton("OK",
                        new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface arg0,
                                                int arg1) {

                            }
                        }).setPositiveButton("View Details",new DialogInterface.OnClickListener(){
                            public void onClick(DialogInterface dialog, int which) {
                                String url = centralModel.getPdf();
                                Intent i = new Intent(Intent.ACTION_VIEW);
                                i.setData(Uri.parse(url));
                                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(i);
                            }
                        });
                alertbox.show();
            }
        });




    }

    @Override
    public int getItemCount() {
        return centralModels.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView centralname;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            centralname=itemView.findViewById(R.id.centralname);
        }

    }
}
